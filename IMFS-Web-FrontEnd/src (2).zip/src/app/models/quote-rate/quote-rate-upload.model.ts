export class QuoteRateUploadModel {
    Funder: string;
    FileName: string;
    File: string;
}