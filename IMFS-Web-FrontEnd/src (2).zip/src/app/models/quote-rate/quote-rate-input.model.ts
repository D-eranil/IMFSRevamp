export class QuoteRateInputModel {
    FunderId: number;
    ProductType: number;
    FinanceType: number;
    VendorId: number;
}
