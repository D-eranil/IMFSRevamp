export class HttpResponseData {
    public status: string;
    public message: string;
    public data: string;
    public ReturnObj: any;
    public Id: any;
    public quoteId: any;
    public searchResult: any;
}
