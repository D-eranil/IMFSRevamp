
export class QuotePercentRateInputModel {
    FunderId: number;
    FinanceType: number;
    ProductType: number;
    FunderPlan: number;
}
