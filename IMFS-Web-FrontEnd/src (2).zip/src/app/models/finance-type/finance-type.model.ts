export class FinanceTypeModel{
    id: number;
    quoteDurationType: number;
    description: string;
    isActive: boolean;
    createdDate: Date;
    modifiedDate: Date;
}
