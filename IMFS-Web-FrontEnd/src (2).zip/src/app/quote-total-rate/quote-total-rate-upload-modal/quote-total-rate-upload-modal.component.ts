import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Dropdown } from 'primeng/dropdown';
import { MessageService, SortEvent } from 'primeng/api';
import { FileUpload } from 'primeng/fileupload';
import { HttpClientModule } from '@angular/common/http';
import { QuoteTotalRateControllerService } from 'src/app/services/controller-services/quote-total-rate-controller.service';
import { FunderControllerService } from 'src/app/services/controller-services/funder-controller.service';

import { FinanceProductTypeControllerService } from 'src/app/services/controller-services/finance-product-type-controller.servcie';
import { FinanceTypeControllerService } from 'src/app/services/controller-services/finance-type-controller.service';
import { IMFSUtilityService } from 'src/app/services/utility-services/imfs-utility-services';
import { FunderModel } from 'src/app/models/funder/funder.model';

import { FinanceProductTypeModel } from 'src/app/models/finance-product-type/finance-product-type.model';
import { FinanceTypeModel } from 'src/app/models/finance-type/finance-type.model';
import { JsUtilityService } from 'src/app/services/utility-services/js-utility.service';
import { FunderPlanModel } from 'src/app/models/funder-plan/funder-plan.model';
import { FunderPlanControllerService } from 'src/app/services/controller-services/funder-plan-controller.service';

@Component({
    selector: 'app-quote-total-rate-upload-modal',
    templateUrl: './quote-total-rate-upload-modal.component.html',
})
export class QuoteTotalRateUploadModalComponent implements OnInit {
    displayDialog = false;
    funderPlans: FunderPlanModel[];
    selectedFunderPlan: number;
    @Output() refreshEmit = new EventEmitter();

    financeTypes: FinanceTypeModel[]; // Lease, rental, instalment etc
    selectedFinanceType: number;

    funders: FunderModel[];
    selectedFunder: number;

    filesToUpload: File[] = [];
    fileNamesToUpload: string;

    @ViewChild('fileUpload') fileUpload: FileUpload;

    constructor(
        private imfsUtilityService: IMFSUtilityService,
        private jsUtilityService: JsUtilityService,
        private quoteTotalRateControllerService: QuoteTotalRateControllerService,
        private funderControllerService: FunderControllerService,
        private funderPlanControllerService: FunderPlanControllerService,
        private financeProductTypeControllerService: FinanceProductTypeControllerService,
        private financeTypeControllerService: FinanceTypeControllerService,
        private messageService: MessageService,
    ) {

        this.loadFunders();
        this.loadFinanceTypes();
        this.loadFunderPlans();
    }

    ngOnInit() {


    }

    open() {
        this.displayDialog = true;
        this.filesToUpload = [];
        this.fileNamesToUpload = '';
        this.fileUpload.clear();   // clear all existing files
    }

    loadFunderPlans() {
        const that = this;

        // tslint:disable-next-line: deprecation
        that.funderPlanControllerService.getFunderPlans().subscribe(
            (response: FunderPlanModel[]) => {
                that.funderPlans = response;
            },
            (err: any) => {
                console.log(err);
                that.imfsUtilityService.showToastr('error', 'Failed', 'Error loading funder plans');
            }
        );
    }

    loadFunders() {
        const that = this;

        // tslint:disable-next-line: deprecation
        that.funderControllerService.getFunders().subscribe(
            (response: FunderModel[]) => {
                that.funders = response;
            },
            (err: any) => {
                console.log(err);
                that.imfsUtilityService.showToastr('error', 'Failed', 'Error loading funders');
            }

        );
    }

    loadFinanceTypes() {
        const that = this;

        that.financeTypeControllerService.getFinanceTypes().subscribe(
            (response: FinanceTypeModel[]) => {
                that.financeTypes = response;
            },
            (err: any) => {
                console.log(err);
                that.imfsUtilityService.showToastr('error', 'Failed', 'Error loading Finance Types');
            }

        );
    }

    onSelect(event: any) {

        const fileNames: string[] = [];

        for (const file of event.files) {
            this.filesToUpload.push(new File([file], file.name));
            fileNames.push(file.name);
        }

        this.fileNamesToUpload = fileNames.join('\n').toString();
    }

    uploadRates() {
        if (!this.filesToUpload) {
            return;
        }
        const that = this;
        const formData: FormData = new FormData();

        if (that.selectedFunder === undefined || that.selectedFunder === null) {
            that.imfsUtilityService.showToastr('error', 'Funder Type', 'Please select Funder Type');
            return;
        }
        else {
            formData.append('Funder', that.selectedFunder.toString());
        }

        if (that.selectedFinanceType === undefined || that.selectedFinanceType === null) {
            that.imfsUtilityService.showToastr('error', 'Finance Type', 'Please select Finance ngType');
            return;
        }
        else {
            formData.append('FinanceType', that.selectedFinanceType.toString());
        }

        if (that.selectedFunderPlan === undefined || that.selectedFunderPlan === null) {
            that.imfsUtilityService.showToastr('error', 'Funder Plan', 'Please select Funder Plan');
            return;
        }
        else {
            formData.append('FunderPlan', that.selectedFunderPlan.toString());
        }

        for (const file of this.filesToUpload) {
            formData.append('Files', file, file.name);
        }

        this.imfsUtilityService.showLoading('Uploading Quote Total Rates, please wait it might take a while...');
        this.quoteTotalRateControllerService.uploadQuoteTotalRates(formData).subscribe(
            (response: any) => {
                this.filesToUpload = [];
                this.fileNamesToUpload = '';
                this.fileUpload.clear();   // clear all existing files
                this.imfsUtilityService.hideLoading();
                if (response.status === 'Success') {
                    this.imfsUtilityService.showToastr('success', 'Upload Successful', 'Successfully uploaded file.');
                    this.displayDialog = false;
                } else {
                    this.imfsUtilityService.showDialog('Error in Upload Quote Total Rate', response.message);
                    console.log('Error in Upload Quote Total Rate: ' + response.message);
                }
            },
            (err: any) => {
                this.imfsUtilityService.hideLoading();
                console.log(err);
                this.imfsUtilityService.showToastr('error', 'Error', 'Unable to upload file.');
            }
        );
    }
}
