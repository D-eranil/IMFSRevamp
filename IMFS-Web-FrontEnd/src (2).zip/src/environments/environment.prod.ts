export const environment = {
  production: true,
  DisplayFunderPlan: true,

  InactivityTime: 60000,
  WaitForLogoutTime: 30,
};
