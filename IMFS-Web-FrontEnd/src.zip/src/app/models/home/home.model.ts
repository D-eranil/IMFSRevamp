export class Home {
}

//export class RecentQuotes {
//  QuoteNumber: number = 0;
//  QuoteName: string = '';
//  EndCustomerName: string = '';
//  QuoteTotal: number = 0;
//  Status: string = '';
//  QuoteExpiryDate: Date = new Date();
//  QuoteCreatedDate: Date = new Date();
//  QuoteLastModified: Date = new Date();
//}

//export class RecentApplications {
//  Id: number = 0;
//  ApplicationNumber: number = 0;
//  endUser: string = '';
//  Status: string = '';
//  FinanaceAmount: number = 0;
//  FinanceType: string = '';
//  CreatedDate: Date = new Date();
//}

//export class AwaitingInvoices {
//  Id: number = 0;
//  ApplicationNumber: number = 0;
//  Status: string = '';
//  EndCustomerName: string = '';
//  FinanaceAmount: number = 0;
//  FinanceType: string = '';
//  CreatedDate: Date = new Date();
//  ApprovedDate: Date = new Date();
//}
