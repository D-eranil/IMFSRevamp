export class FunderModel{
    id: number;
    funderCode: string;
    funderName: string;
    // tslint:disable-next-line: variable-name
    apI_URL: string;
    contactEmailAdd: string;
    isActive: boolean;
    createdDateTime: Date;
    lastModifiedDateTime: Date;
}
