export class OTCModel {
    code: string;
    quoteId: string;

}

export class OTCEncryptionModel {
    encryptedQuoteId: string;
}

