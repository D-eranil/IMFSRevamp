
export class QuoteTotalRateInputModel {
    FunderId: number;
    FinanceType: number;
    FunderPlan: number;
}
