export class FunderPlanModel {
    planId: number;
    planDescription: string;
}
