export class LoadingBarModel {
    showLoading: boolean;
    loadingMessage: string;
    showCancelButton: boolean;
    cancelAction: () => void;
}
