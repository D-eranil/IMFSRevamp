export class ComponentVisibliyModel {
    public ExcludeList: boolean;
    public ComponentName: string;
    public RoutePathList: string[];
}
