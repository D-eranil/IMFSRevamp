import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { ComponentVisibliyModel } from '../../models/misc/component-visibility.model';
import { BroadcasterService } from './broadcaster.service';
import { environment } from './../../../environments/environment';
import { OktaService } from './okta.service';

@Injectable()

export class IdleTimeoutService {

    interval: any;
    userActivity: any;
    showInactivityAlert: boolean = false;
    showInactivityAlertSubject: Subject<boolean> = new Subject();
    userInactive: Subject<any> = new Subject();

    timeLeft: number = environment.WaitForLogoutTime;
    timeleftSubject: Subject<number> = new Subject();
    inactivityTime: number = environment.InactivityTime;

    constructor(private oktaService: OktaService) {
    }

    public set setInactivityTime(InactivityTime: number) {
      this.inactivityTime = InactivityTime;
    }

    refreshUserState() {
    clearTimeout(this.userActivity);
    clearTimeout(this.interval);
    if(this.showInactivityAlert){
      this.showInactivityAlert = !this.showInactivityAlert;
      this.showInactivityAlertSubject.next(false);
    }
    this.setTimeout();
    }

    init() {
      if(this.oktaService.isLoggedIn){
        this.setTimeout();

        this.userInactive.subscribe(() => {
          this.showInactivityAlert = true;
          this.showInactivityAlertSubject.next(true);
          this.logoutAfterTime();
        });
      }
    }

    setTimeout() {
      this.userActivity = setTimeout(
        () => this.userInactive.next(undefined),
        this.inactivityTime
      );
    }

    logoutAfterTime() {
      this.interval = setInterval(() => {
        if(this.timeLeft > 0) {
          this.timeLeft--;
        } else {
          this.showInactivityAlert = false;
          this.showInactivityAlertSubject.next(false);
          this.oktaService.logout();
          this.oktaService.afterLogout();
          clearInterval(this.interval)
        }
      },1000)
    }



}
